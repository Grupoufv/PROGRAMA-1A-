import java.io.*;
import java.util.Arrays;

public class Interface {
	 public static void main (String[] args ) throws IOException{
	        InputStreamReader isr = new InputStreamReader(System.in);
	        BufferedReader br = new BufferedReader(isr);
	        Sistema entrada = new Sistema();
	        int competidores = Integer.parseInt(br.readLine());
	        int vagas = Integer.parseInt(br.readLine());
	        int atual;
	        int rank[] = new int[1001];
	        int comp[]=new int[competidores];
	       
	        int ans = 0;
	        for(int x=0; x<competidores; x++){
	            atual = Integer.parseInt(br.readLine());
	            comp[x]=atual;
	            rank[atual]++;
	            
	           
	        }
	        
	        for(int x=1000; x>=0; x--){
	            if(vagas>0){
	                if(rank[x]!=0){
	                    vagas -=rank[x];
	                    ans+=rank[x];
	                }
	            }else{
	                break;
	            }
	        }
	        
	        int aprovados[]=new int [ans];
	       
	        for(int i=0; i<ans;i++) {
	        	aprovados[i]=comp[i];
	        }
	         
	        for(int i=0;i<comp.length;i++) {
	            comp[i]=-comp[i];
	        }

	        Arrays.sort(comp);

	        for(int i=0;i<comp.length;i++) {

	            comp[i]=-comp[i]; 
	        }
	        for(int i=0; i<ans;i++) {
	        	aprovados[i]=comp[i];
	        	
	        }
	       
	        System.out.println(ans);
	        entrada.Calculos(aprovados); 
	        entrada.Exibir();
	        entrada.Calculos(comp); 
	        entrada.Exibir();
	    }
}
