import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class testePSP {
	  @Test
		public void CalculaMedia()  {
			int[] numeros={1,2,3,4,5,6};
			Sistema sis = new Sistema();;
			sis.Calculos (numeros);
			Sistema sis2 = new Sistema();;
			sis2.Calculos (numeros);
			assertEquals(sis.getMedia(),sis2.getMedia());
		}
	    @Test
		 public void CalculaVariancia()  {
			int[] numeros={1,2,3,4,5,6};
			Sistema sis = new Sistema();
			Sistema sis2 = new Sistema();
			sis.Calculos (numeros);
			sis2.Calculos (numeros);
			assertEquals(sis.getVariancia(),sis2.getVariancia());
		}
	    @Test
		 public void CalculaDP()  {
			int[] numeros={1,2,3,4,5,6};
			Sistema sis = new Sistema();
			Sistema sis2 = new Sistema();
			sis.Calculos (numeros);
			sis2.Calculos (numeros);
			assertEquals(sis.getDesvioPadrao(),sis2.getDesvioPadrao());
		}
	    @Test
		 public void CalculaCoeficienteVariacao()  {
			int[] numeros={1,2,3,4,5,6};
			Sistema sis = new Sistema();;
			sis.Calculos (numeros);
			Sistema sis2 = new Sistema();;
			sis2.Calculos (numeros);
			assertEquals(sis.getCoeficienteVariacao(),sis2.getCoeficienteVariacao());
		}
	
	
}
