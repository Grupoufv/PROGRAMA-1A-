import java.text.DecimalFormat;
import java.util.Locale;

public class Sistema {
	private int[] numeros;
	private float media;
	private double variancia;
	private double desvioPadrao;
	private double coeficienteVariacao;
	
	public void Calculos(int[] numeros) {
		this.numeros = numeros;
		calculoGeral(); 
	}
	
	private void calculoGeral() {
		// Calcular todas as fun��es e gravar nas vari�veis
		Locale.setDefault(new Locale("en", "US"));
		calcularMedia();
		calcularVariancia();
		calcularDesvioPadrao();
		calcularCoeficienteVariacao();
	}
	 
	
	public void Exibir() {
		
		DecimalFormat dec = new DecimalFormat("#0.00");
		
		System.out.println( dec.format(this.media));
		
		System.out.println(dec.format(this.desvioPadrao));
		
	}
	
	public void instanciarNovosNumeros(int[] numeros) {
		this.numeros = numeros;
		calculoGeral();
	}
	
	private void calcularMedia() {
		// Calcular a m�dia
		float somaTotal = 0;
		for (int i = 0; i < numeros.length; i++) {
			somaTotal += numeros[i];
		}
		this.media = somaTotal / numeros.length;
	}
	 
	public void calcularVariancia() {
		// Calcular 
		float somaNumeros = 0.0f;
		for (int i = 0; i < numeros.length; i++) {
			somaNumeros += Math.pow(media - numeros[i], 2);
		}
		
		
		double resultado;
		
			resultado = somaNumeros / numeros.length;
		
		
		this.variancia = resultado;
	}
	
	public double calcularVariancia2() {
		// F�rmula 2 - (E(x�) / n) - u�
		double somaNumeros = 0.0f;
		for (int i = 0; i < numeros.length; i++) {
			somaNumeros += Math.pow(numeros[i], 2);
		}
		double resultado = (somaNumeros / numeros.length) - Math.pow(media, 2);		
		return resultado;
	}
	
	public void calcularDesvioPadrao() {
		this.desvioPadrao = Math.sqrt(this.variancia);
	}
	
	public void calcularCoeficienteVariacao() {
		// Coeficiente de Varia��o - Desvio padr�o / m�dia (x 100 para apresentar a porcentagem)
		this.coeficienteVariacao = this.desvioPadrao / this.media;
	}
	
	
	public double getCoeficienteVariacao() {
		return this.coeficienteVariacao;
	}
	

	public float getMedia() {
		return media;
	}

	public double getVariancia() {
		return variancia;
	}

	public double getDesvioPadrao() {
		return desvioPadrao;
	}
	
	
}
